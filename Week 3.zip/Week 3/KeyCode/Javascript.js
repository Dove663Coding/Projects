const displayKey = document.querySelector('.key h2');
const displayKeyCode = document.querySelector('.keyCode h2');
const displayEventCode = document.querySelector('.eventCode h2');
const overlay = document.querySelector('.overlay');


//Pressing a key will remove the splash screen. Any subquesent key presses will translate the key into Char Code and Event Code.
window.addEventListener('keydown', (e)=>{
    overlay.classList.add('hide');
    displayKey.innerText = e.key;
    displayKeyCode.innerText = e.keyCode;
    displayEventCode.innerText = e.code;
    //Displays the text "Space" for when the Space Bar is pressed.
    if(e.keyCode === 32){
        displayKey.innerText = 'Space';
    }

})


