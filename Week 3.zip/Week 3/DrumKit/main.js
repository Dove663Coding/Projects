// Sounds
let boom = document.getElementById("boom");
let clap = document.getElementById("clap");
let hithat = document.getElementById("hithat");
let kick = document.getElementById("kick");
let openhat = document.getElementById("openhat");
let ride = document.getElementById("ride");
let snare = document.getElementById("snare");
let tink = document.getElementById("tink");
let tom = document.getElementById("tom");
// Induvidual Keys
let keyOne = document.getElementById("key1");
let keyTwo = document.getElementById("key2");
let keyThree = document.getElementById("key3");
let keyFour = document.getElementById("key4");
let keyFive = document.getElementById("key5");
let keySix = document.getElementById("key6");
let keySeven = document.getElementById("key7");
let keyEight = document.getElementById("key8");
let keyNine = document.getElementById("key9");

//Keyboard Script
//Since the key values is case sensitive, two sets of values need to be created for both upper and lower case keypresses.
//Pressing a key starts a sound effect and an animation to represent the pressed key. Null values are used to remove the
//border after it have been animated.
document.addEventListener('keypress', (keyValue) => {
    if (keyValue.keyCode == 97) {
        boom.pause()
        boom.currentTime = 0
        boom.play();
        keyOne.style.borderColor = 'rgba(0,0,255,0.8)'
        keyOne.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyOne.style.borderColor = null;
            keyOne.style.transform = null;
        }, 100)
        
    }else if (keyValue.keyCode == 65) {
        boom.pause()
        boom.currentTime = 0
        boom.play();
        keyOne.style.borderColor = 'rgba(0,0,255,0.8)'
        keyOne.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyOne.style.borderColor = null;
            keyOne.style.transform = null;
        }, 100)
    } 
     else if (keyValue.keyCode == 115) {
        clap.pause()
        clap.currentTime = 0
        clap.play();
        keyTwo.style.borderColor = 'rgba(0,0,255,0.8)'
        keyTwo.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyTwo.style.borderColor = null;
            keyTwo.style.transform = null;
        }, 100)
    } else if (keyValue.keyCode == 83) {
        clap.pause()
        clap.currentTime = 0
        clap.play();
        keyTwo.style.borderColor = 'rgba(0,0,255,0.8)'
        keyTwo.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyTwo.style.borderColor = null;
            keyTwo.style.transform = null;
        }, 100)
    }
     else if (keyValue.keyCode == 100) {
        hithat.pause()
        hithat.currentTime = 0
        hithat.play();
        keyThree.style.borderColor = 'rgba(0,0,255,0.8)'
        keyThree.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyThree.style.borderColor = null;
            keyThree.style.transform = null;
        }, 100)
    }   else if (keyValue.keyCode == 68) {
        hithat.pause()
        hithat.currentTime = 0
        hithat.play();
        keyThree.style.borderColor = 'rgba(0,0,255,0.8)'
        keyThree.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyThree.style.borderColor = null;
            keyThree.style.transform = null;
        }, 100)
    }else if (keyValue.keyCode == 102) {
        kick.pause()
        kick.currentTime = 0
        kick.play();
        keyFour.style.borderColor = 'rgba(0,0,255,0.8)'
        keyFour.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyFour.style.borderColor = null;
            keyFour.style.transform = null;
        }, 100)
    } else if (keyValue.keyCode == 70) {
        kick.pause()
        kick.currentTime = 0
        kick.play();
        keyFour.style.borderColor = 'rgba(0,0,255,0.8)'
        keyFour.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyFour.style.borderColor = null;
            keyFour.style.transform = null;
        }, 100)
    } else if (keyValue.keyCode == 103) {
        openhat.pause()
        openhat.currentTime = 0
        openhat.play();
        keyFive.style.borderColor = 'rgba(0,0,255,0.8)'
        keyFive.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyFive.style.borderColor = null;
            keyFive.style.transform = null;
        }, 100)
    } else if (keyValue.keyCode == 71) {
        openhat.pause()
        openhat.currentTime = 0
        openhat.play();
        keyFive.style.borderColor = 'rgba(0,0,255,0.8)'
        keyFive.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyFive.style.borderColor = null;
            keyFive.style.transform = null;
        }, 100)
    }else if (keyValue.keyCode == 104) {
        ride.pause()
        ride.currentTime = 0
        ride.play();
        keySix.style.borderColor = 'rgba(0,0,255,0.8)'
        keySix.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keySix.style.borderColor = null;
            keySix.style.transform = null;
        }, 100)
    }
    else if (keyValue.keyCode == 72) {
        ride.pause()
        ride.currentTime = 0
        ride.play();
        keySix.style.borderColor = 'rgba(0,0,255,0.8)'
        keySix.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keySix.style.borderColor = null;
            keySix.style.transform = null;
        }, 100)
    }  
     else if (keyValue.keyCode == 106) {
        snare.pause()
        snare.currentTime = 0
        snare.play();
        keySeven.style.borderColor = 'rgba(0,0,255,0.8)'
        keySeven.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keySeven.style.borderColor = null;
            keySeven.style.transform = null;
        }, 100)
    }
    else if (keyValue.keyCode == 74) {
        snare.pause()
        snare.currentTime = 0
        snare.play();
        keySeven.style.borderColor = 'rgba(0,0,255,0.8)'
        keySeven.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keySeven.style.borderColor = null;
            keySeven.style.transform = null;
        }, 100)
    }
     else if (keyValue.keyCode == 107) {
        tink.pause()
        tink.currentTime = 0
        tink.play();
        keyEight.style.borderColor = 'rgba(0,0,255,0.8)'
        keyEight.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyEight.style.borderColor = null;
            keyEight.style.transform = null;
        }, 100)
    } else if (keyValue.keyCode == 75) {
        tink.pause()
        tink.currentTime = 0
        tink.play();
        keyEight.style.borderColor = 'rgba(0,0,255,0.8)'
        keyEight.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyEight.style.borderColor = null;
            keyEight.style.transform = null;
        }, 100)
    }else if (keyValue.keyCode == 108) {
        tom.pause()
        tom.currentTime = 0
        tom.play();
        keyNine.style.borderColor = 'rgba(0,0,255,0.8)'
        keyNine.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyNine.style.borderColor = null;
            keyNine.style.transform = null;
        }, 100)
    }else if (keyValue.keyCode == 76) {
        tom.pause()
        tom.currentTime = 0
        tom.play();
        keyNine.style.borderColor = 'rgba(0,0,255,0.8)'
        keyNine.style.transform = 'scale(1.1)'
        setTimeout(() => {
            keyNine.style.borderColor = null;
            keyNine.style.transform = null;
        }, 100)
    }
  })

//Click Script
//Clicking each button will start a sound effect.
document.getElementById('key1').addEventListener('click', cl_Div);
function cl_Div() {
    boom.pause()
    boom.currentTime = 0
    boom.play();  
}
document.getElementById('key2').addEventListener('click', cl_Div2);
function cl_Div2() {
    clap.pause()
    clap.currentTime = 0
    clap.play();  
}
document.getElementById('key3').addEventListener('click', cl_Div3);
function cl_Div3() {
    hithat.pause()
    hithat.currentTime = 0
    hithat.play();  
}
document.getElementById('key4').addEventListener('click', cl_Div4);
function cl_Div4() {
    kick.pause()
    kick.currentTime = 0
    kick.play();  
}
document.getElementById('key5').addEventListener('click', cl_Div5);
function cl_Div5() {
    openhat.pause()
    openhat.currentTime = 0
    openhat.play();  
}
document.getElementById('key6').addEventListener('click', cl_Div6);
function cl_Div6() {
    ride.pause()
    ride.currentTime = 0
    ride.play();  
}
document.getElementById('key7').addEventListener('click', cl_Div7);
function cl_Div7() {
    snare.pause()
    snare.currentTime = 0
    snare.play();  
}
document.getElementById('key8').addEventListener('click', cl_Div8);
function cl_Div8() {
    tink.pause()
    tink.currentTime = 0
    tink.play();  
}
document.getElementById('key9').addEventListener('click', cl_Div9);
function cl_Div9() {
    tom.pause()
    tom.currentTime = 0
    tom.play();  
}
